import e from"./ClientSuport.54e16469.js";import{j as t}from"./index.39423856.js";localStorage.getItem("new");function i(){return t("div",{children:t(e,{})})}export{i as default};

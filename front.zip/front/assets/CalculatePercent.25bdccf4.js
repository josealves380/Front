function a(o,t){const e=(parseFloat(o.replace(",","."))*100/t).toFixed(2);return console.log(e),e}export{a as C};

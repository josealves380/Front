import{o as a}from"./index.39423856.js";const o=localStorage.getItem("basic"),s=a.create({baseURL:"https://www.f2b.com.br/api/v1",headers:{Authorization:`Basic ${o}`}});export{s as f};

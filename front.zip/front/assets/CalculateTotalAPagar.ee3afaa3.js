function l(a,o){return(parseFloat(a.replace(",","."))*o/100).toFixed(2)}export{l as C};

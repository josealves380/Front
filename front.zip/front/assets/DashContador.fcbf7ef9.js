import{b as r,j as a,H as s,S as d}from"./index.39423856.js";function i(){return r("div",{children:[a(s,{}),a("div",{children:"DashContador"}),a(d,{})]})}export{i as default};
